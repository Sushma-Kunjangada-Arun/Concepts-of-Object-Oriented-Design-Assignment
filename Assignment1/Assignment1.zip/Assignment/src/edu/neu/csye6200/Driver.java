package edu.neu.csye6200;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("============Main Execution Start===================\n\n");
		
		Cart.demo();
		
		System.out.println("\n\n============Main Execution End===================");

	}

}
